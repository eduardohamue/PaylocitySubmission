package main;

import java.util.Scanner;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import test.TestAddingEmployee;
import test.TestDeleteEmployee;
import test.TestEditingEmployee;
import test.TestLogin;

public class Main {

	public static void main(String[] args) {
		System.out.println("Wellcome to automation testing Paylocity");
		
		Scanner scanner = new Scanner(System.in);
		
		int option = 0;
		while (option <1 || option >4) {
			try {
				System.out.println("Please select the type of testing that you want to do");
				System.out.println("1. Login Testing");
				System.out.println("2. Add Employee Testing");
				System.out.println("3. Edit Employee Testing");
				System.out.println("4. Delete Employee Testing");
				option = scanner.nextInt();
				
				if(option <1 || option >4) {
					System.out.println("Please select an option between 1 and 4");
				}
				
			} catch (Exception e) {
				System.out.println("Please select a valid option");
			}
		}
		Result result = new Result();
		switch (option) {
			case 1:
		        result = JUnitCore.runClasses(TestLogin.class);
		        break;
		    
			case 2:
		        result = JUnitCore.runClasses(TestAddingEmployee.class);
		        break;
		        
			case 3:
				result = JUnitCore.runClasses(TestEditingEmployee.class);
		        break;
		        
			case 4:
				result = JUnitCore.runClasses(TestDeleteEmployee.class);
		        break;
		        
			default:
				System.out.println("An error happened, please try again");
		        	
		}
		
        System.out.println("Execution total time: " + result.getRunTime() + " ms");

        
        if (result.getFailureCount() >0) {
            System.out.println(result.getFailureCount() + " test failed:");
            for (Failure failure : result.getFailures()) {
                System.out.println("Test failed: " + failure.getTestHeader());
                System.out.println("Root faile: " + failure.getMessage());
            }
        } else {
            System.out.println("The test was successfull!!!");
        }
    }

}
