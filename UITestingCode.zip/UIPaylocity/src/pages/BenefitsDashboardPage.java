package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;

public class BenefitsDashboardPage {
	WebDriver driver;
	WebDriverWait wait;
	
	@FindBy(xpath = "//li[@class='nav-item']//a")
	WebElement logOutLink;
	
	
	@FindBy(xpath = "//td[text()='TestingToEdit']//..//i[@class='fas fa-edit']")
	WebElement editTestingIcon;
	
	@FindBy(xpath = "//td[text()='Testing2']//..//i[@class='fas fa-edit']")
	WebElement editTesting2Icon;
	
	
	@FindBy(xpath = "//td[text()='TestingToDelete']//..//i[@class='fas fa-times']")
	WebElement deleteTestingIcon;
	
	@FindBy(xpath = "//td[text()='Testing2']//..//i[@class='fas fa-times']")
	WebElement deleteTesting2Icon;
	
	@FindBy(id = "add")
	WebElement addButton;
	
	@FindBy(id = "firstName")
	WebElement firstNameTxt;
	
	
	@FindBy(id = "lastName")
	WebElement lastNameTxt;
	
	@FindBy(id = "dependants")
	WebElement dependantsTxt;
	
	@FindBy(id = "addEmployee")
	WebElement addEmployeeBtn;
	
	@FindBy(xpath = "//td[text()='Testing']")
	WebElement employeeCeld;
	
	@FindBy(xpath = "//td[text()='TestingToEdit2']")
	WebElement employee2Celd;
	
	@FindBy(xpath = "//td[text()='TestingToDelete']")
	WebElement employeeToDeleteCeld;
	
	@FindBy(id = "deleteEmployee")
	WebElement deleteButton;
	
	@FindBy(id = "updateEmployee")
	WebElement updateButton;
	
	
	public BenefitsDashboardPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		PageFactory.initElements(driver, this);
	}
	
	public void addEmployee() {
		clickLayzyElement(addButton);
		wait.until(ExpectedConditions.visibilityOf(firstNameTxt));
		firstNameTxt.sendKeys("Testing");
		lastNameTxt.sendKeys("Testing");
		dependantsTxt.sendKeys("0");
		addEmployeeBtn.click();
	}
	
	
	public void addEmployeeToDelete() {
		clickLayzyElement(addButton);
		wait.until(ExpectedConditions.visibilityOf(firstNameTxt));
		firstNameTxt.sendKeys("TestingToDelete");
		lastNameTxt.sendKeys("TestingToDelete");
		dependantsTxt.sendKeys("0");
		addEmployeeBtn.click();
	}
	
	
	public void addEmployeeToEdit() {
		clickLayzyElement(addButton);
		wait.until(ExpectedConditions.visibilityOf(firstNameTxt));
		firstNameTxt.sendKeys("TestingToEdit");
		lastNameTxt.sendKeys("TestingToEdit");
		dependantsTxt.sendKeys("0");
		addEmployeeBtn.click();
	}
	
	
	public void edit() {
		clickLayzyElement(editTestingIcon);

		wait.until(ExpectedConditions.visibilityOf(firstNameTxt));
		firstNameTxt.sendKeys("2");
		lastNameTxt.sendKeys("2");
		dependantsTxt.sendKeys("0");
		updateButton.click();
		
	}
	
	
	public void logOut() {
		wait.until(ExpectedConditions.visibilityOf(logOutLink));
		logOutLink.click();
	}
	
	public void validateAccessToSystem() {
		wait.until(ExpectedConditions.visibilityOf(logOutLink));
	}
	
	public void validateTestingEmployee() {
		
		wait.until(ExpectedConditions.visibilityOf(employeeCeld));
		
	}
	
	public void validateTestingEmployee2() {
		
		wait.until(ExpectedConditions.visibilityOf(employee2Celd));

		
	}
	

	
	public void deleteEmployeeTesting() {
		clickLayzyElement(deleteTestingIcon);

		clickLayzyElement(deleteButton);

		
	}
	
	public void deleteEmployeeTesting2() {
		clickLayzyElement(deleteTesting2Icon);
		wait.until(ExpectedConditions.visibilityOf(deleteButton));
		deleteButton.click();
		
	}
	
	public void clickLayzyElement(WebElement element) {
		wait.until(ExpectedConditions.visibilityOf(element));
		wait.until(ExpectedConditions.elementToBeClickable(element));
		element.click();
	}
	

}
