package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	WebDriver driver;
	
	@FindBy(id="Username")
	WebElement usernameTxt;
	
	
	@FindBy(id="Password")
	WebElement passwordTxt;
	
	@FindBy(css = ".btn.btn-primary")
	WebElement loginButton;
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void login() {
		usernameTxt.sendKeys("TestUser447");
		passwordTxt.sendKeys("-rlV;H+uX1nh");
		loginButton.click();
	}
	
	
	

}
