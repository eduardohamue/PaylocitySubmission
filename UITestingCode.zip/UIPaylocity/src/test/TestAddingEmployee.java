package test;


import java.time.Duration;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import pages.BenefitsDashboardPage;
import pages.LoginPage;

public class TestAddingEmployee {
	
	WebDriver driver;
	String baseUrl;
	LoginPage loginPage;
	BenefitsDashboardPage benefitsDashboardPage;
	
	@Before
	public void setUp() throws Exception {
		driver = new FirefoxDriver();
		baseUrl = "https://wmxrwq14uc.execute-api.us-east-1.amazonaws.com/Prod/Account/Login";
		
		loginPage = new LoginPage(driver);
		benefitsDashboardPage = new BenefitsDashboardPage(driver);
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		driver.get(baseUrl);
	}

	@Test
	public void test() {
		//Access to the site
		loginPage.login();
		
		//Add employee
		benefitsDashboardPage.addEmployee();
		
		//Validate that the employee exist
		benefitsDashboardPage.validateTestingEmployee();
		
		//Log out of the system
		benefitsDashboardPage.logOut();
		
	}
	
	@After
	public void tearDown() throws Exception {
		//Close Browser
		Thread.sleep(2000);
		driver.quit();
	}


}
