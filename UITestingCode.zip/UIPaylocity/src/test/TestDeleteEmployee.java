package test;


import java.time.Duration;
import org.junit.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import pages.BenefitsDashboardPage;
import pages.LoginPage;

public class TestDeleteEmployee {
	
	WebDriver driver;
	String baseUrl;
	LoginPage loginPage;
	BenefitsDashboardPage benefitsDashboardPage;
	
	@Before
	public void setUp() throws Exception {
		driver = new FirefoxDriver();
		baseUrl = "https://wmxrwq14uc.execute-api.us-east-1.amazonaws.com/Prod/Account/Login";
		
		loginPage = new LoginPage(driver);
		benefitsDashboardPage = new BenefitsDashboardPage(driver);
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		driver.get(baseUrl);
	}

	@Test
	public void test() {
		//Access to the site
		loginPage.login();
		
		//Add employee
		benefitsDashboardPage.addEmployeeToDelete();
		
		//Delete employee
		benefitsDashboardPage.deleteEmployeeTesting();
		
		//Validate that the element is removed
		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(3));
        boolean elementIsInvisible = wait2.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//td[text()='TestingToDelete']")));
        Assert.assertTrue("The employee still exist", elementIsInvisible);
		
        //Log out of the system
		benefitsDashboardPage.logOut();
		
	}
	
	@After
	public void tearDown() throws Exception {
		//Close Browser
		Thread.sleep(2000);
		driver.quit();
	}


}
